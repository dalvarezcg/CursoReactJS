import Messages from "./component/Messages"; 

function App() {
    return (
        <div>
            <Messages/>
        </div>
    )
}
export default App